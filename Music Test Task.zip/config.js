module.exports = {
    SOUNDCLOUD_KEY:'vvWDsm284DNe9CDlRlfb3wuseloIl1RS'
}